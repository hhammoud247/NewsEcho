const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const multer = require("multer");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const dotenv = require("dotenv");
const mysql = require("mysql2");

dotenv.config();
console.log("MYSQL_HOST:", process.env.MYSQL_HOST);
console.log("MYSQL_USER:", process.env.MYSQL_USER);
console.log("MYSQL_PASSWORD:", process.env.MYSQL_PASSWORD);
console.log("MYSQL_DB:", process.env.MYSQL_DB);

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use("/uploads", express.static("uploads"));

// MySQL Connection
const db = mysql.createConnection({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DB,
});

db.connect((err) => {
  if (err) {
    console.error("Database connection error:", err.message);
  } else {
    console.log("Connected to MySQL database");
  }
});

// Middleware for JWT Authentication
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Access denied" });

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: "Invalid token" });
    req.user = user;
    next();
  });
};

// Multer Configuration for File Uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// Routes

// Authentication Routes
app.post("/api/auth/signup", async (req, res) => {
  const { username, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const query = "INSERT INTO users (username, password) VALUES (?, ?)";
    db.query(query, [username, hashedPassword], (err) => {
      if (err) {
        return res.status(400).json({ message: "Error creating user", error: err.message });
      }
      res.json({ message: "User created successfully" });
    });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  const query = "SELECT * FROM users WHERE username = ?";
  db.query(query, [username], async (err, results) => {
    if (err || results.length === 0) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    const user = results[0];
    if (!(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.json({ token });
  });
});

// Articles Routes
app.get("/api/articles", (req, res) => {
  const { lang } = req.query;
  const query = lang ? "SELECT * FROM articles WHERE lang = ?" : "SELECT * FROM articles";
  db.query(query, lang ? [lang] : [], (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Error fetching articles", error: err.message });
    }
    res.json(results);
  });
});

app.post("/api/articles", authenticateToken, upload.single("image"), (req, res) => {
  const { title, content, lang } = req.body;
  const image = req.file ? `/uploads/${req.file.filename}` : null;
  const query = "INSERT INTO articles (title, content, lang, image) VALUES (?, ?, ?, ?)";
  db.query(query, [title, content, lang, image], (err) => {
    if (err) {
      return res.status(400).json({ message: "Error creating article", error: err.message });
    }
    res.json({ message: "Article created successfully" });
  });
});

app.delete("/api/articles/:id", authenticateToken, (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM articles WHERE id = ?";
  db.query(query, [id], (err) => {
    if (err) {
      return res.status(400).json({ message: "Error deleting article", error: err.message });
    }
    res.json({ message: "Article deleted successfully" });
  });
});

// Ads Routes
app.get("/api/ads", (req, res) => {
  const { lang } = req.query;
  const query = lang ? "SELECT * FROM ads WHERE lang = ?" : "SELECT * FROM ads";
  db.query(query, lang ? [lang] : [], (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Error fetching ads", error: err.message });
    }
    res.json(results);
  });
});

app.post("/api/ads", authenticateToken, upload.single("image"), (req, res) => {
  const { title, link, lang } = req.body;
  const image = req.file ? `/uploads/${req.file.filename}` : null;
  const query = "INSERT INTO ads (title, link, lang, image) VALUES (?, ?, ?, ?)";
  db.query(query, [title, link, lang, image], (err) => {
    if (err) {
      return res.status(400).json({ message: "Error creating ad", error: err.message });
    }
    res.json({ message: "Ad created successfully" });
  });
});

app.delete("/api/ads/:id", authenticateToken, (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM ads WHERE id = ?";
  db.query(query, [id], (err) => {
    if (err) {
      return res.status(400).json({ message: "Error deleting ad", error: err.message });
    }
    res.json({ message: "Ad deleted successfully" });
  });
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
