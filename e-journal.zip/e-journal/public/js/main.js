const translations = {
    en: {
      "Home": "Home",
      "Admin Login": "Admin Login",
      "English": "English",
      "عربي": "Arabic",
      "Admin Signup": "Admin Signup",
    },
    ar: {
      "Home": "الصفحة الرئيسية",
      "Admin Login": "تسجيل دخول المسؤول",
      "English": "الإنجليزية",
      "عربي": "عربي",
      "Admin Signup": "تسجيل مسؤول",
    },
  };
  
  document.querySelectorAll(".lang-switch").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const lang = e.target.getAttribute("data-lang");
      document.querySelectorAll(".nav-link").forEach((link) => {
        const key = link.textContent.trim();
        link.textContent = translations[lang][key];
      });
    });
  });
  