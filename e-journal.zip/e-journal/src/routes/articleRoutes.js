const express = require("express");
const multer = require("multer");
const { authMiddleware } = require("../middlewares/authMiddleware");
const {
  createArticle,
  getArticles,
  deleteArticle,
} = require("../controllers/articleController");

const router = express.Router();

// Multer setup for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "public/images"),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage });

router.get("/", getArticles);
router.post("/", authMiddleware, upload.single("image"), createArticle);
router.delete("/:id", authMiddleware, deleteArticle);

module.exports = router;
