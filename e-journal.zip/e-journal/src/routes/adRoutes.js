const express = require("express");
const multer = require("multer");
const { authMiddleware } = require("../middlewares/authMiddleware");
const { createAd, getAds, deleteAd } = require("../controllers/adController");

const router = express.Router();

// Multer setup for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "public/images"),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});
const upload = multer({ storage });

router.get("/", getAds);
router.post("/", authMiddleware, upload.single("image"), createAd);
router.delete("/:id", authMiddleware, deleteAd);

module.exports = router;
