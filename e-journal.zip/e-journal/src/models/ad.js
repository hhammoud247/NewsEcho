const mongoose = require("mongoose");

const adSchema = new mongoose.Schema({
  title: { type: String, required: true },
  image: { type: String, required: true }, // Path to the uploaded image
  link: { type: String }, // URL where the ad points to
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Ad", adSchema);
