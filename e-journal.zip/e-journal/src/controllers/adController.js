const Ad = require("../models/ad");

exports.createAd = async (req, res) => {
  try {
    const { title, link } = req.body;
    const image = req.file ? `/images/${req.file.filename}` : null;

    if (!image) return res.status(400).json({ message: "Image is required" });

    const ad = new Ad({ title, link, image });
    await ad.save();

    res.status(201).json({ message: "Ad created successfully", ad });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

exports.getAds = async (req, res) => {
  try {
    const ads = await Ad.find().sort({ createdAt: -1 });
    res.status(200).json(ads);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

exports.deleteAd = async (req, res) => {
  try {
    const { id } = req.params;
    const ad = await Ad.findById(id);
    if (!ad) return res.status(404).json({ message: "Ad not found" });

    await ad.remove();
    res.status(200).json({ message: "Ad deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};
