const Article = require("../models/article");

exports.createArticle = async (req, res) => {
  try {
    const { title, content } = req.body;
    const image = req.file ? `/images/${req.file.filename}` : null;

    const article = new Article({
      title,
      content,
      image,
      author: req.user.id, // Authenticated user's ID
    });

    await article.save();
    res.status(201).json({ message: "Article created successfully", article });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

exports.getArticles = async (req, res) => {
  try {
    const articles = await Article.find().populate("author", "username").sort({ createdAt: -1 });
    res.status(200).json(articles);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

exports.deleteArticle = async (req, res) => {
  try {
    const { id } = req.params;
    const article = await Article.findById(id);
    if (!article) return res.status(404).json({ message: "Article not found" });

    // Only the author can delete the article
    if (article.author.toString() !== req.user.id) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    await article.remove();
    res.status(200).json({ message: "Article deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};
